package com.app.carmanagement.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.*;

@Entity
@Table(name = "carmodel")
public class CarModel {

@Id
@Column(nullable = false, unique = true)
private int carId;
private String carModel;
private String carNo;
private String status;

public CarModel() {
	super();
}

public CarModel(int carId, String carModel, String carNo, String status) {
	super();
	this.carId = carId;
	this.carModel = carModel;
	this.carNo = carNo;
	this.status = status;
}

public int getCarId() {
	return carId;
}

public void setCarId(int carId) {
	this.carId = carId;
}

public String getCarModel() {
	return carModel;
}

public void setCarModel(String carModel) {
	this.carModel = carModel;
}

public String getCarNo() {
	return carNo;
}

public void setCarNo(String carNo) {
	this.carNo = carNo;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

}