package com.app.carmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.app.carmanagement.model.CarModel;

public interface CarRepository extends JpaRepository<CarModel, Long>{

	public CarModel findByCarId(int carId);
	public CarModel save(CarModel car);
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM CarModel e WHERE e.carId = :carId")      
    int deleteByCarId(@Param("carId") int carId);
	
}
