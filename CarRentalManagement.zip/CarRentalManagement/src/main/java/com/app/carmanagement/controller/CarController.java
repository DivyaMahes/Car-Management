package com.app.carmanagement.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.carmanagement.model.CarModel;
import com.app.carmanagement.service.CarService;

@RestController
public class CarController {
	@Autowired
	private CarService service;

	 public CarController(CarService service) {
	        this.service = service;
	 }
		
	 @PostMapping("/saveCar")
	 public CarModel createRole(@RequestBody CarModel role) {
	      return service.saveUser(role);
	 }
	 
	 @PutMapping("/editCar/{carId}")
	 public CarModel editCar(@PathVariable String carId, @RequestBody CarModel car) {
		 return service.saveUser(car);
	 }
	 
	 @DeleteMapping("/deleteCar/{carId}")
	 public Iterable<CarModel> deleteUser(@PathVariable int carId) {
		 service.deleteCarById(carId);
		 return service.showAllCars();
	 }

	 @GetMapping("/getCars")
	 public Iterable<CarModel> showAllCars() {
		 return service.showAllCars();
	 }
	 
	 @GetMapping("/getCar/{carId}")
	 public CarModel showCarsById(@PathVariable int carId) {
		return service.fetchCarBycarId(carId);
	 }
	 
}