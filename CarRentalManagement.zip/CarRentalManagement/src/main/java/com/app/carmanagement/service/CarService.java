package com.app.carmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.carmanagement.model.CarModel;
import com.app.carmanagement.repository.CarRepository;

@Service
public class CarService {

	@Autowired
	private CarRepository repo;
	
	public CarModel saveUser(CarModel user) {
		return repo.save(user);
	}
	
	public Iterable<CarModel> showAllCars() {
		return repo.findAll();
	}
		
	public CarModel fetchCarBycarId(int carId) {
		return repo.findByCarId(carId);
	}
	
	public void deleteCarById(int carId) {
		repo.deleteByCarId(carId);
	}
	
	
}
