package com.app.carmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarRentalManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarRentalManagementApplication.class, args);
	}

}
